import express from "express";
const app=express(), port=process.env.PORT||3000, key=process.env.ALPHA_VANTAGE_API_KEY;
app.use(express.static("public"));
let cache={at:0,data:null};
async function av(params){
 if(!key) throw new Error("ALPHA_VANTAGE_API_KEY is not configured");
 const u=new URL("https://www.alphavantage.co/query");
 for(const [k,v] of Object.entries({...params,apikey:key}))u.searchParams.set(k,v);
 const r=await fetch(u); if(!r.ok)throw new Error("Alpha Vantage HTTP "+r.status);
 const j=await r.json();
 if(j["Error Message"]||j["Note"])throw new Error(j["Error Message"]||j["Note"]);
 return j;
}
function latest(obj){
 const data=obj?.data||obj||{};
 const rows=Object.entries(data).filter(([k,v])=>/^\d{4}-\d{2}-\d{2}/.test(k)&&v&&typeof v==="object").sort((a,b)=>b[0].localeCompare(a[0]));
 if(!rows.length)return null;
 const r=rows[0][1], keys=["value","2. high","10. year treasury yield","1. open"];
 for(const k of keys)if(r[k]!=null&&r[k]!=="")return Number(r[k]);
 const x=Object.values(r).find(v=>v!==""); return x==null?null:Number(x);
}
app.get("/api/health",(_,res)=>res.json({ok:true,alphaVantageConfigured:Boolean(key)}));
app.get("/api/macro",async(_,res)=>{
 if(cache.data&&Date.now()-cache.at<60000)return res.json(cache.data);
 const out={fetchedAt:new Date().toISOString(),values:{},sources:{}};
 const qs=[
  ["gold",{function:"GOLD_SILVER_SPOT",symbol:"GOLD"}],
  ["us2y",{function:"TREASURY_YIELD",interval:"daily",maturity:"2year"}],
  ["us10y",{function:"TREASURY_YIELD",interval:"daily",maturity:"10year"}],
  ["fed",{function:"FEDERAL_FUNDS_RATE",interval:"daily"}],
  ["cpi",{function:"CPI",interval:"monthly"}]
 ];
 for(const [name,q] of qs)try{
   const d=await av(q);
   const v=name==="gold"?Number(d.price??d["Gold Spot Price"]??d.data?.[0]?.value):latest(d);
   out.values[name]=Number.isFinite(v)?v:null; out.sources[name]="Alpha Vantage";
 }catch(e){out.values[name]=null;out.sources[name]=e.message}
 out.values.dxy=null; out.sources.dxy="TradingView";
 cache={at:Date.now(),data:out}; res.json(out);
});
app.listen(port,()=>console.log("Gold Macro Dashboard on "+port));
