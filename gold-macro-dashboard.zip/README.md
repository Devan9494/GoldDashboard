# Gold Macro Dashboard

Upload this folder to GitHub, then deploy it as a Render Web Service.
Build: `npm install`
Start: `npm start`
Add `ALPHA_VANTAGE_API_KEY` as a Render environment variable.

Do not put the API key in the frontend.
